#ifndef IMAGE_H
#define IMAGE_H
namespace stb {
#define STB_IMAGE_IMPLEMENTATION
#include "sensorData/stb_image.h"
	

#define STB_IMAGE_WRITE_IMPLEMENTATION
#include "sensorData/stb_image_write.h"
}
#endif

#pragma once

//
// ext-depthcamera headers
//
#include "ext-depthcamera/calibratedSensorData.h"	//this is obsolete
#include "ext-depthcamera/sensorData.h"
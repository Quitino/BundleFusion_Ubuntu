
//
// external lodepng source
//
#include "../src/ext-lodepng/lodepng.cpp"

//
// ext-lodepng source files
//
#include "../src/ext-lodepng/imageLoaderLodePNG.cpp"

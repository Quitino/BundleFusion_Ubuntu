
#include "main.h"

#include "mLibCore.cpp"
#include "mLibLodePNG.cpp"
#include "mLibZLib.cpp"
#include "mLibDepthCamera.cpp"